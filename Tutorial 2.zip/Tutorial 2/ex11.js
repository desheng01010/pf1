const originalString = "Pokemon";

let reversedString = "";

for (let i = originalString.length - 1; i >= 0; i--) {
    reversedString += originalString[i];
}

console.log("Reversed string:", reversedString);
