let i = 1; 
let j = 1; 

while (i <= 5) { 
    console.log(i * 3); 
    i = i + 1; 
}
