const numbers = [6, 5, 4, 7, 5];

let sum = 0;

for (let i = 0; i < numbers.length; i++) {
    sum += numbers[i];
}

console.log("The sum of all elements in the array is:", sum);//27