const arr = ["Hello", 21, "Food", 1, "HAHA"];

console.log("Elements of the array:");
for (const element of arr) {
    console.log(element);
}
