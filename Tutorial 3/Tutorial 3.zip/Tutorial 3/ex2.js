let Colours = ["Red","Yellow","Purple","Green"];
Colours.pop(); //To Remove the last element
Colours.shift(); //To Remove the first element
console.log(Colours);