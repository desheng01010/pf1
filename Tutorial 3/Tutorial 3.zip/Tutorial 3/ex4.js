let num = 5;
let str = "5";

if (num === str){
    console.log("There are equal")
} else {
    console.log ("There are type different")
}