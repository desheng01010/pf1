function addNumbers(a, b) {
    var sum = Number(a) + Number(b);
    console.log(sum);
}

addNumbers(10, '20'); 
