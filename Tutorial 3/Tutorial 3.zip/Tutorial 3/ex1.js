// Creating Arrays

//[Creating Literal]
let arr = ["apple","orange","pineapple"];
arr.push("mango");
arr.unshift("Strawberry");
console.log(arr);



/*//[Array Constructor]
let arr = new Array ("apple", "orange", "pineapple");

//[Creating Instance with new]
let arr = new Array();
arr[0] = "apple";
arr[1] = "orange";
arr[2] = "pineapple";*/

