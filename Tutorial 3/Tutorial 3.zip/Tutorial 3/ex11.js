function minsToSecs(minutes) {
    // Convert Minutes to Seconds
    var seconds = minutes * 60;
    return seconds;
}

// Testing the function with sample inputs
console.log("5 minutes =", minsToSecs(5), "seconds");
console.log("10 minutes =", minsToSecs(10), "seconds");
console.log("3 minutes =", minsToSecs(3), "seconds");
