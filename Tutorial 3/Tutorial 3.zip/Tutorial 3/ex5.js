function areaRectangle(width, height) {
    // Compute the area
    var area = width * height;
    // Return the result
    return area;
}

// Testing the function with different sets of values
console.log("Area of rectangle with width 5 and height 10:", areaRectangle(5, 10));
console.log("Area of rectangle with width 7 and height 3:", areaRectangle(7, 3));
console.log("Area of rectangle with width 12 and height 8:", areaRectangle(12, 8));
